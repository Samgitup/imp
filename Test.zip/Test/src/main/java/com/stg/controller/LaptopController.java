/*
 * package com.stg.controller;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.http.MediaType; import
 * org.springframework.web.bind.annotation.DeleteMapping; import
 * org.springframework.web.bind.annotation.ExceptionHandler; import
 * org.springframework.web.bind.annotation.GetMapping; import
 * org.springframework.web.bind.annotation.PathVariable; import
 * org.springframework.web.bind.annotation.PostMapping; import
 * org.springframework.web.bind.annotation.PutMapping; import
 * org.springframework.web.bind.annotation.RequestBody; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.ResponseBody; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * import com.stg.exception.LaptopException; import com.stg.model.Brand; import
 * com.stg.model.Laptop; import com.stg.repo.LaptopRepo; import
 * com.stg.service.BrandServiceImpl; import com.stg.service.LaptopServiceImpl;
 * 
 * @RestController
 * 
 * @RequestMapping(value = "/get") public class LaptopController {
 * 
 * @Autowired private LaptopServiceImpl laptopServiceImpl;
 * 
 * @PostMapping(value = "/createlaptop", consumes =
 * MediaType.APPLICATION_JSON_VALUE) public String createBrand(@RequestBody
 * Laptop laptop) { return laptopServiceImpl.createLaptop( laptop); }
 * 
 * @GetMapping(value = "/getlaptopbyid/{laptopId}") public Laptop
 * getBrandById(@PathVariable int laptopId) {
 * 
 * return laptopServiceImpl.getLaptopById(laptopId);
 * 
 * }
 * 
 * @GetMapping(value =
 * "/getlaptopbylaptopIdandlaptopName/{laptopId}/{laptopName}", produces =
 * MediaType.APPLICATION_JSON_VALUE) public Laptop
 * getLaptopByLaptopIdAndLaptopName(@PathVariable int laptopId, @PathVariable
 * String laptopName) { return
 * laptopServiceImpl.getLaptopBybrandIdAndbrandName(laptopId, laptopName); }
 * 
 * @PutMapping(value = "/updatelaptop", produces =
 * MediaType.APPLICATION_JSON_VALUE, consumes =
 * MediaType.APPLICATION_JSON_VALUE) public Laptop updateBrand(@RequestBody
 * Laptop laptopId) { return laptopServiceImpl.updateLaptopDetails(laptopId); }
 * 
 * @DeleteMapping(value = "/deletelaptopbyid/{laptopId}") public String
 * deleteLaptopById(@PathVariable int laptopId) { return
 * laptopServiceImpl.deleteLaptopById(laptopId); }
 * 
 * 
 * 
 * @ExceptionHandler(value = com.stg.exception.LaptopException.class) public
 * String exceptionThrower(LaptopException laptopException) { return
 * laptopException.getMessage(); }
 * 
 * 
 * 
 * }
 */