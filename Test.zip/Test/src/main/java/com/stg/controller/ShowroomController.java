
package com.stg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stg.exception.BrandException;
import com.stg.exception.LaptopException;
import com.stg.exception.ShowroomException;
import com.stg.model.Brand;
import com.stg.model.Laptop;
import com.stg.model.LaptopShowroom;
import com.stg.service.BrandServiceImpl;
import com.stg.service.LaptopServiceImpl;
import com.stg.service.ShowroomServiceImpl;

@RestController

@RequestMapping(value = "/shop")
public class ShowroomController {

	@Autowired
	private ShowroomServiceImpl showroomServiceImpl;
	
	@Autowired
	private BrandServiceImpl brandServiceImpl;
	
	@Autowired
	private LaptopServiceImpl laptopServiceImpl;

	@PostMapping(value = "/createshowroom", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String createShowroom(@RequestBody LaptopShowroom showroom) {
		return showroomServiceImpl.createByShowroom(showroom);
	}

	@GetMapping(value = "/getshowroombyid/{showroomId}")
	public LaptopShowroom getShowroomById(@PathVariable int showroomId) {

		return showroomServiceImpl.getShowroomById(showroomId);

	}

	@GetMapping(value = "/getshowroombyshowroomIdandshowroomName/{showroomId}/{showroomName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public LaptopShowroom getShowroomByShowroomIdAndShowroomName(@PathVariable int showroomId,
			@PathVariable String showroomName) {
		return showroomServiceImpl.getShowroomByShowroomIdAndShowroomName(showroomId, showroomName);
	}

	@PutMapping(value = "/updateshowroom", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public LaptopShowroom updateShowroom(@RequestBody LaptopShowroom showroom) {
		return showroomServiceImpl.updateShowroomDetails(showroom);
	}

	@DeleteMapping(value = "/deleteshowroombyid/{showroomId}")
	public String deleteShowroomById(@PathVariable int showroomId) {
		return showroomServiceImpl.deletetById(showroomId);
	}

	@ExceptionHandler(value = com.stg.exception.ShowroomException.class)
	public String exceptionThrower(ShowroomException showroomException) {
		return showroomException.getMessage();
	}
	
	
	/////////////////////////////////////////////////// Brand ////////////////////////////////////////////////////////////////////
	
	

	@PostMapping(value = "/createbrand", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String createBrand(@RequestBody Brand brand) {
		return brandServiceImpl.createBrand(brand);
	}

	@GetMapping(value = "/getbrandbyid/{brandId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Brand getBrandById(@PathVariable int brandId) {

		return brandServiceImpl.getBrandById(brandId);

	}

	@GetMapping(value = "/getbrandbybrandIdandbrandName/{brandId}/{brandName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Brand getBrandByBrandIdAndBrandName(@PathVariable int brandId, @PathVariable String brandName) {
		return brandServiceImpl.getBrandBybrandIdAndbrandName(brandId, brandName);
	}

	@PutMapping(value = "/updatebrand", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Brand updateBrand(@RequestBody Brand brand) {
		return brandServiceImpl.updateBrandDetails(brand);
	}

	@DeleteMapping(value = "/deletebrandbyid/{brandId}")
	public String deleteBrandById(@PathVariable int brandId) {
		return brandServiceImpl.deleteBrandById(brandId);
	}

	@ExceptionHandler(value = com.stg.exception.BrandException.class)
	public String exceptionThrower(BrandException brandException) {
		return brandException.getMessage();
	}
	
	
	
//////////////////////////////////////  Laptop controller /////////////////////////////////////////////////////////////////
	
	
	@PostMapping(value = "/createlaptop", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String createLaptop(@RequestBody Laptop laptop) {
		return laptopServiceImpl.createLaptop(laptop);
	}

	@GetMapping(value = "/getlaptopbyid/{laptopId}")
	public Laptop getLaptopById(@PathVariable int laptopId) {

		return laptopServiceImpl.getLaptopById(laptopId);

	}

	@GetMapping(value = "/getlaptopbylaptopIdandlaptopName/{laptopId}/{laptopName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Laptop getLaptopByLaptopIdAndLaptopName(@PathVariable int laptopId, @PathVariable String laptopName) {
		return laptopServiceImpl.getLaptopBybrandIdAndbrandName(laptopId, laptopName);
	}

	@PutMapping(value = "/updatelaptop", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Laptop updateLaptop(@RequestBody Laptop laptopId) {
		return laptopServiceImpl.updateLaptopDetails(laptopId);
	}

	@DeleteMapping(value = "/deletelaptopbyid/{laptopId}")
	public String deleteLaptopById(@PathVariable int laptopId) {
		return laptopServiceImpl.deleteLaptopById(laptopId);
	}

	@ExceptionHandler(value = com.stg.exception.LaptopException.class)
	public String exceptionThrower(LaptopException laptopException) {
		return laptopException.getMessage();
	}

}
