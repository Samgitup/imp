package com.stg.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;

//import org.hibernate.mapping.Set;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "brand_b")
public class Brand {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "brand_id")
	private int brandId;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "showroom_id",referencedColumnName = "showroomId")
	@JsonBackReference
	private LaptopShowroom showroom;
	@Column(name = "brand_name")
	private String brandName;

	@Column(name = "version")
	private String version;

	@JsonManagedReference
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "brands")
	private Set<Laptop> laptops;

	public Brand() {
		super();
	}

	public Brand(int brandId, String brandName, String version, Set<Laptop> laptops) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.version = version;
		this.laptops = laptops;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Set<Laptop> getLaptops() {
		return laptops;
	}

	public void setLaptops(Set<Laptop> laptops) {
		this.laptops = laptops;
	}

}
