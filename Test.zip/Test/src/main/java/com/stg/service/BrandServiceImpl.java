package com.stg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.stg.exception.BrandException;
import com.stg.model.Brand;
import com.stg.repo.BrandRepo;

@Service
public class BrandServiceImpl implements BrandService {
	@Autowired
	BrandRepo brandRepo;
	
	@Override
	public String createBrand(Brand brand) throws BrandException {
		brandRepo.save(brand);
		return "Brand Created Successfully";
	}
	@Override
	public  Brand getBrandById(int brandId) throws BrandException {
		Brand temp= brandRepo.findByBrandId(brandId);
		if( temp != null) {
			return temp ;
		}else {
			throw new BrandException("No  found with that Brand Id");
		}
	}
	@Override
	public Brand getBrandBybrandIdAndbrandName(int brandId, String brandName) throws BrandException {
		Brand brand = brandRepo.findByBrandIdAndBrandName(brandId, brandName);
		if(brand!=null) {
			return brand;
		}else {
			throw new BrandException("Wrong Brand details");
		}
	}
	@Override
	public Brand updateBrandDetails(Brand brand) throws BrandException {
		int brandId = brand.getBrandId();
		Brand updatedBrand=null;
		Brand resbrand = brandRepo.findByBrandId(brandId);
		if(resbrand!=null) {
			 updatedBrand = brandRepo.save(brand);
		}else {
			throw new BrandException("No BrandId");
		}
		return  updatedBrand;
	}
	@Override
	public String deleteBrandById(int brandId) throws BrandException {
		Brand brand = brandRepo.findByBrandId(brandId);
		if(brand!=null) {
			brandRepo.delete(brand);
		}else {
//			throw new BrandException("No brand with that Id");
		}
		
		
		return  " Brand Deleted Successfully";
	}


}
