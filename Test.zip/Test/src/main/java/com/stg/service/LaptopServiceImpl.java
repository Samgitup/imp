package com.stg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stg.exception.BrandException;
import com.stg.exception.LaptopException;
import com.stg.model.Brand;
import com.stg.model.Laptop;
import com.stg.repo.LaptopRepo;
@Service
public class LaptopServiceImpl implements LaptopService{
@Autowired
LaptopRepo laptopRepo;

@Override
public String createLaptop(Laptop laptop) throws LaptopException {
	laptopRepo.save(laptop);
	return "Laptop Created Successfully";
}

@Override
public Laptop getLaptopById(int laptopId) throws LaptopException {
	Laptop ans= laptopRepo.findByLaptopId(laptopId);
	if( ans!=null) {
		return ans;
	}else {
		throw new BrandException("No  found with that Laptop Id");
	}

}

@Override
public Laptop getLaptopBybrandIdAndbrandName(int laptopId, String laptopName) throws LaptopException {
	Laptop laptop = laptopRepo.findByLaptopIdAndLaptopName(laptopId, laptopName);
	if(laptop!=null) {
		return laptop;
	}else {
		throw new BrandException("Wrong laptop details");
	}
}
	


@Override
public Laptop updateLaptopDetails(Laptop laptop) throws LaptopException {
	int laptopId = laptop.getLaptopId();
	Laptop updatedlaptop=null;
	Laptop reslaptop = laptopRepo.findByLaptopId(laptopId);
	if(reslaptop!=null) {
		updatedlaptop = laptopRepo.save(laptop);
	}else {
		throw new LaptopException("No LaptopId");
	}
	return  updatedlaptop;
}


@Override
public String deleteLaptopById(int laptopId) throws LaptopException {
	Laptop laptop = laptopRepo.findByLaptopId(laptopId);
	if(laptop!=null) {
		laptopRepo.delete(laptop);
	}else {
		throw new BrandException("No Laptop with that Id");
	}
	
	return  " Laptop Deleted Successfully";
}
}



