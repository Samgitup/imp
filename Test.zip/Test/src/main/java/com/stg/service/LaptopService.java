package com.stg.service;

import com.stg.exception.LaptopException;
import com.stg.model.Laptop;

public interface LaptopService {
	public abstract String createLaptop(Laptop laptop) throws LaptopException;

	public abstract Laptop getLaptopById(int laptopId) throws LaptopException;

	public abstract Laptop getLaptopBybrandIdAndbrandName(int laptopId, String laptopName) throws LaptopException;

	public abstract Laptop updateLaptopDetails(Laptop laptop) throws LaptopException;

	public abstract String deleteLaptopById(int laptopId) throws LaptopException;

}
