package com.stg.service;

import com.stg.exception.ShowroomException;
import com.stg.model.LaptopShowroom;

public interface ShowroomService {
 
	public abstract String createByShowroom(LaptopShowroom showroom  ) throws ShowroomException;
	
	public abstract LaptopShowroom getShowroomById(int showroomId)throws ShowroomException;
	
	public abstract LaptopShowroom getShowroomByShowroomIdAndShowroomName(int showroomId,String showroomName)throws ShowroomException;
	
	public abstract LaptopShowroom updateShowroomDetails(LaptopShowroom showroom)throws ShowroomException;
	
	public abstract String deletetById(int showroomId)throws ShowroomException;
	
}
