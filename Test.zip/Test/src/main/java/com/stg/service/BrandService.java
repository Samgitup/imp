package com.stg.service;

import java.util.List;

import com.stg.exception.BrandException;
import com.stg.model.Brand;

public interface BrandService {

	public abstract String createBrand(Brand brand) throws BrandException;

	public abstract Brand getBrandById(int brandId) throws BrandException;

	public abstract Brand getBrandBybrandIdAndbrandName(int brandId, String brandName) throws BrandException;

	public abstract Brand updateBrandDetails(Brand brand) throws BrandException;

	public abstract String deleteBrandById(int brandId) throws BrandException;

}
