package com.stg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stg.exception.BrandException;
import com.stg.exception.ShowroomException;
import com.stg.model.Brand;
import com.stg.model.LaptopShowroom;
import com.stg.repo.ShowroomRepo;

@Service
public class ShowroomServiceImpl implements ShowroomService {

	@Autowired
	ShowroomRepo showroomRepo;

	@Override
	public String createByShowroom(LaptopShowroom showroom) throws ShowroomException {
		LaptopShowroom updatedShowroom = null;
		LaptopShowroom showroom2=showroomRepo.findByShowroomName(showroom.getShowroomName());
		
		if(showroom2.getShowroomName().equals(showroom.getShowroomName()) && showroom2.getLocation().equals(showroom.getLocation()))
		{
			throw new ShowroomException("Already this Showroom is Exists");
		}else
		{
			updatedShowroom =showroomRepo.save(showroom);
		}
		
		return " Showroom Created Successfully";
	}

	@Override
	public LaptopShowroom getShowroomById(int showroomId) throws ShowroomException {
		LaptopShowroom ans = showroomRepo.findByShowroomId(showroomId);
		if (ans != null) {
			return ans;
		} else {
			throw new ShowroomException("No  found with that Brand Id");
		}
	}

	@Override
	public LaptopShowroom getShowroomByShowroomIdAndShowroomName(int showroomId, String showroomName)
			throws ShowroomException {
		LaptopShowroom ans = showroomRepo.findByShowroomIdAndShowroomName(showroomId, showroomName);
		
		if (ans != null) {
			return ans;
		} else {
			throw new ShowroomException("Wrong Brand details");
		}
	}

	@Override
	public LaptopShowroom updateShowroomDetails(LaptopShowroom showroom) throws ShowroomException {
		int ShowroomId = showroom.getShowroomId();
		LaptopShowroom updatedShowroom=null;
		LaptopShowroom resShowroom = showroomRepo.findByShowroomId(ShowroomId);
		if(resShowroom!=null) {
			 updatedShowroom = showroomRepo.save(showroom);
		}else {
			throw new BrandException("No ShowroomId");
		}
		return  updatedShowroom;
	}

	@Override
	public String deletetById(int showroomId) throws ShowroomException {
LaptopShowroom ans = showroomRepo.findByShowroomId(showroomId);
		
		if (ans != null) {
			 showroomRepo.deleteById(showroomId); ;
		} else {
			throw new ShowroomException(" No showroom with that id");
		}
		return "showroom Deleted Successfully";
	}
}
