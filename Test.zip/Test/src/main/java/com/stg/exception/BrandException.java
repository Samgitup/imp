package com.stg.exception;

public class BrandException extends RuntimeException{
	private static final long serialVersionUID = 1L;
		
		private String message;

		public BrandException(String message) {
			
			this.message = message;
		}

		@Override
		public String getMessage() {
			return this.message;
		}

}