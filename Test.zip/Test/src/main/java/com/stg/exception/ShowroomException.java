package com.stg.exception;

public class ShowroomException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	@Override
	public String getMessage() {
		return this.getMessage();
	}

	private String message;

	public ShowroomException(String message) {
		
		this.message = message;
	}


	

	



}
