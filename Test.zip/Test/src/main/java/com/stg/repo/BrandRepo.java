package com.stg.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.stg.model.Brand;

@Repository
public interface BrandRepo extends CrudRepository<Brand, Integer> {
	
	
	public Brand findByBrandId(int brandId);
        public Brand findByBrandIdAndBrandName(int brandId, String brandName);
}

