package com.stg.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.stg.model.LaptopShowroom;
@Repository
public interface ShowroomRepo extends CrudRepository<LaptopShowroom, Integer> {
	
	public LaptopShowroom findByShowroomId(int showroomId);
	
	public LaptopShowroom findByShowroomIdAndShowroomName(int showroomId,String showroomName);

	public LaptopShowroom findByShowroomName(String showroomName);
}
