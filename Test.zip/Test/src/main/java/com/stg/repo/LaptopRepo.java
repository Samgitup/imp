package com.stg.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.stg.model.Laptop;

@Repository
public interface LaptopRepo extends CrudRepository<Laptop, Integer> {
	
	
	public Laptop findByLaptopId(int laptopId);
        public Laptop findByLaptopIdAndLaptopName(int laptopId, String laptopName);
}
